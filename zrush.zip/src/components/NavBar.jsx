import { Button, Typography } from "@mui/material";
import React from "react";

const NavBar = () => {
  return (
    <React.Fragment>
   
   

    </React.Fragment>
  );
};

export default NavBar;
