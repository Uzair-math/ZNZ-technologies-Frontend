import React from 'react'
import SigninPage from '../components/signin/SigninPage'

const Signin = () => {
  return (
    <div>
      <SigninPage/>
    </div>
  )
}

export default Signin
