import React from 'react'
import SignuPage from '../components/signup/SignuPage'

const Signup = () => {
  return (
    <div>
      <SignuPage/>
    </div>
  )
}

export default Signup
